/*------feet to inch---------*/

var feet = document.getElementById('feet');
var inch = document.getElementById('inch');

feet.addEventListener('input', function () {
    let f = this.value;
    let i = f * 12;
    inch.value = i;
});
inch.addEventListener('input', function () {
    let i = this.value;
    let f = i / 12;
    if (!Number.isInteger(f)) {
        f = f.toFixed(2);
    };
    feet.value = f;
});

/*------meter to centimeter---------*/

var meter = document.getElementById('meter');
var centimeter = document.getElementById('centimeter');

meter.addEventListener('input', function () {
    let m = this.value;
    let c = m * 100;
    centimeter.value = c;
})
centimeter.addEventListener('input', function () {
    let c = this.value;
    let m = c / 100;
    if (!Number.isInteger(m)) {
        m = m.toFixed(2);
    };
    meter.value = m;
});
/*------meters to milimeters---------*/

var meters = document.getElementById('meters');
var milimeters = document.getElementById('milimeters');

meters.addEventListener('input', function () {
    let m1 = this.value;
    let m2 = m1 * 1000;
    milimeters.value = m2;
})
milimeters.addEventListener('input', function () {
    let m2 = this.value;
    let m1 = m2 / 1000;
    if (!Number.isInteger(m1)) {
        m1 = m1.toFixed(2);
    };
    meters.value = m1;
});
/*------centimeters to milimeters---------*/

var centimeters = document.getElementById('centimeters');
var milimeter = document.getElementById('milimeter');

centimeters.addEventListener('input', function () {
    let cm = this.value;
    let mm = cm * 10;
    milimeter.value = mm;
})
milimeter.addEventListener('input', function () {
    let mm = this.value;
    let cm = mm / 10;
    if (!Number.isInteger(cm)) {
        cm = cm.toFixed(2);
    };
    centimeters.value = cm;
});